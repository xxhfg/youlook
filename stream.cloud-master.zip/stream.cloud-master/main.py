#! /usr/bin/env python
# -*- coding: utf-8 -*-
import stream

if __name__ == '__main__' :
    stream.run ()


