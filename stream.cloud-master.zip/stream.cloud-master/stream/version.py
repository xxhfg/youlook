#! /usr/bin/env python
# -*- coding: utf-8 -*-

PRIMARY = 0 
SECONDARY = 0 
MINOR = 1
FIX = 1 

VERSION = '%d.%d.%d.%d'%(PRIMARY, SECONDARY, MINOR, FIX)
