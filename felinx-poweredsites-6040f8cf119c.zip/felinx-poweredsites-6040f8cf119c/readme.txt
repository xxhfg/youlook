PoweredSites was originally created at July 2010 by Felinx <felinx.lee@gmail.com>,
and open-sourced to community under Apache License.

Please visit http://blog.poweredsites.org for latest news about 
PoweredSites project.